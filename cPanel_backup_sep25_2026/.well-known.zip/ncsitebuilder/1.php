<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : ""); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
	<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : ""); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20190528040158" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20190528040159" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1559586143" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1559586143" rel="stylesheet" type="text/css" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body class="site"><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance1" class="wb_element wb_element_picture" title=""><img alt="gallery/clock" src="gallery_gen/2e0735645625471706fdb7957cda376a.png"></div><div id="wb_element_instance2" class="wb_element wb_text_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle">Our website is coming soon</h5></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance3" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2">Contact us</h2></div><div id="wb_element_instance4" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal"><span class="wb-stl-special">This text should be replaced with information about you and your business This text should be replaced with information about you and your business This text should be replaced with information about you and your...</span></p></div><div id="wb_element_instance5" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal"><strong>Address:</strong></p>
<p class="wb-stl-normal">Empire State Building</p>
<p class="wb-stl-normal">350 5th Ave</p>
<p class="wb-stl-normal">New York</p>
<p class="wb-stl-normal">NY 10118</p>
<p class="wb-stl-normal">USA</p>
<p class="wb-stl-normal"> </p>
<p class="wb-stl-normal"><strong>Phone:</strong></p>
<p class="wb-stl-normal"><span style="background-color: transparent;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;">+1 212 736 3100</span></span></span></p>
<p class="wb-stl-normal"> </p>
<p class="wb-stl-normal"><strong>E-mail: </strong></p>
<p class="wb-stl-normal">info@domain.example</p></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 140px;"><div id="wb_element_instance0" class="wb_element wb_element_picture" title=""><img alt="gallery/eb6b9f776a4d4ba5802445cd6854d56d.lock" src="gallery_gen/ffad1189f31c72bb56bf71ba120e4a89_100x40.png"></div><div id="wb_element_instance6" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
