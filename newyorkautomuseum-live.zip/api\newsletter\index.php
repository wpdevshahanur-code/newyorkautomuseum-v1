<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$input = file_get_contents('php://input');
$body = json_decode($input, true);
$email = isset($body['email']) ? trim($body['email']) : '';

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please provide a valid email address.']);
    exit;
}

$endpoint = 'https://admin.newyorkautoexperience.org/wp-admin/admin-ajax.php';
$postData = http_build_query([
    'action' => 'fluentform_submit',
    'form_id' => '4',
    'data' => 'email=' . urlencode($email)
]);

$ch = curl_init($endpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept: application/json, text/javascript, */*; q=0.01',
    'X-Requested-With: XMLHttpRequest',
    'Cookie: hc_js_gate=1'
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($result && !empty($result['success'])) {
    echo json_encode([
        'success' => true,
        'message' => $result['data']['result']['message'] ?? 'Thank you for signing up. You are now subscribed to our newsletter.'
    ]);
} else {
    http_response_code(400);
    $msg = 'Failed to subscribe. Please try again.';
    if (isset($result['errors'])) {
        if (is_string($result['errors'])) {
            $msg = $result['errors'];
        } elseif (is_array($result['errors'])) {
            $first = reset($result['errors']);
            $msg = is_string($first) ? $first : reset($first);
        }
    }
    echo json_encode(['success' => false, 'message' => $msg]);
}
